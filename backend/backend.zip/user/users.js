// user/users.js
const users = [
    { id: 1, item: 'مستخدم 1' },
    { id: 2, item: 'مستخدم 2' },
    { id: 3, item: 'مستخدم 3' },
  ];
  
  module.exports = {
    getUsers: () => users,
  };
  